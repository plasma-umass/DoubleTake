/*
 * $Id: version.h,v 1.126.2.7 2001/07/13 18:17:55 wessels Exp $
 *
 *  SQUID_VERSION - String for version id of this distribution
 */
#ifndef SQUID_VERSION
#define SQUID_VERSION	"2.3.STABLE5"
#endif

#ifndef SQUID_RELEASE_TIME
#define SQUID_RELEASE_TIME 995048446
#endif
